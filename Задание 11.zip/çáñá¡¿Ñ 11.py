# -- coding: utf-8 --
import requests
import json
from tkinter import *

def clicked():
    username = txt.get()

    # username = 'kubernetes'
    url = f'https://api.github.com/users/{username}'
    userdata = requests.get(url).json()
    
    json_dict = {
    'company': userdata['company'],
    'created_at': userdata['created_at'],
    'email': userdata['email'],
    'id': userdata['id'],
    'name': userdata['name'],
    'url': userdata['url']
    }

    with open('userdata.json', 'w') as write_file:
            json.dump(json_dict, write_file)

    curr_data = ''
    for key in json_dict:
        curr_data += f'{key}: {json_dict[key]}\n'
    
    output = 'Файл создан в папке со скриптом\n' + curr_data
    lbl_2.configure(text=output)



window = Tk()
window.title('')
window.geometry('400x250')
lbl = Label(window, text='Введите имя репозитория: ')
lbl.grid(column=0, row=0)
txt = Entry(window, width=30)
txt.grid(column=1, row=0)
btn = Button(window, text='Подтвердить', command=clicked)
btn.grid(column=1, row=1)
lbl_2 = Label(window, text='', anchor='w')
lbl_2.grid(column=0, row=2)
window.mainloop()